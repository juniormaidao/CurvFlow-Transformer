# from graphormer.data import register_dataset
# from dgl.data import QM9
import json
from sklearn.model_selection import train_test_split
# from torch_geometric.datasets import ZINC
import numpy as np
from curvature import numba
import json
from multiprocessing import Pool
from torch_geometric.datasets import MoleculeNet
import sys
import torch
from torch_geometric.data import Dataset, Data
# torch.cuda.is_available()

def floyd_warshall(adjacency_matrix):
    n = adjacency_matrix.shape[0]
    dist = [[float('inf')] * n for _ in range(n)]

    for i in range(n):
        dist[i][i] = 0
        for j in range(n):
            if adjacency_matrix[i][j] == 1:
                dist[i][j] = 1

    for k in range(n):
        for i in range(n):
            for j in range(n):
                if dist[i][k] + dist[k][j] < dist[i][j]:
                    dist[i][j] = dist[i][k] + dist[k][j]

    return np.array(dist)


class MyDataset(Dataset):
    def __init__(self, data_path):
        super(MyDataset, self).__init__()
        self.data_path = data_path
        self.data_list = torch.load(self.data_path)

    def len(self):
        return len(self.data_list)

    def get(self, idx):
        return self.data_list[idx]


def process_data(start_index, end_index):
    # dataset = ZINC(root='MoleculeNet', split='train', subset=False)
    dataset = MoleculeNet(root=r'\data\MoleculeNet', name='toxcast')
    print(len(dataset))
    data_records = []
    for k in range(start_index, end_index):
        data_point = dataset[k]
        print(dataset[k])
        if data_point['x'].size(0) != 0:
            print(f'Processing index: {k}')
            AN = numba.sdrf(data_point)
            data = {
                "idx": k,
                "AN": AN.tolist(),
            }
            data_records.append(data)

    return data_records

if __name__ == '__main__':
    start = 0
    end = 100
    result = process_data(start, end)
    with open(f"charity_{start}_{end}.json", 'w') as json_file:
        json.dump(result, json_file)
    print(f"Data from index {start} to {end} processed and saved.")